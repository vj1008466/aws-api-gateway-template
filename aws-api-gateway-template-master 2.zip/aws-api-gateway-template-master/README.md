# aws-api-gateway-template
A HTML5 site template to be used with AWS API Gateway
